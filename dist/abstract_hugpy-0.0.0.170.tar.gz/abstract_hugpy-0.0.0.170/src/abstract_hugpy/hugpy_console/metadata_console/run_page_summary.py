from .page_summary_generator_fast import run_page_summary_generator_fast
if __name__ == "__main__":
    run_page_summary_generator_fast()
