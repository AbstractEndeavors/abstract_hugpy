from abstract_hugpy.abstract_hugpy.hugpy_console.hugpy_flasks.hugpy_proxyvideo_flask_app import hugpy_proxyvideo_app

app = hugpy_proxyvideo_app()

